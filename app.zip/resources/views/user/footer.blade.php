<div class="footer clearfix">
     <img src="img/money_back.jpg" alt="">
     <div>© COPYRIGHT 2015. IBIDMYHOME.COM. CUSTOMER CARE: 080 444 555</div>
</div>