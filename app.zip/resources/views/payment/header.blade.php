<div class="header">
    <div class="container">
        <div class="logo"><img src="{{ asset('img/project-logo.png') }}"></div>
        <div style="float:right; margin-top: 20px;"><img src="{{ asset('img/logo-provident.svg') }}"></div>
    </div>
</div>
    
<div class="nav" style="padding-top: 100px">
    <div class="container">
   </ul>
        </div>
        
    </div>
    
</div>
